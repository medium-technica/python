
def print_matrix_2d(matrix):
	for i in matrix[:]:
		for j in i[:]:
			print(j, end=' ')
		print ()
		
def load_probability_matrix_from_file(file_name):
	probability_matrix = []
	file = open(file_name, "r")
	i=0
	for line_string in file:
		j=0
		temp_array = (line_string.strip()).split()
		probability_matrix.append([])
		for element in temp_array:
			probability_matrix[i].append(int(element.strip()))
			j+=1
		i+=1
	file.close() 
	print_matrix_2d(probability_matrix)
	size_of_room_grid = [j//3, i//3]
	print(size_of_room_grid)

def resize_probability_matrix(new_size):
	max_size = [max(new_size[0],size_of_room_grid[0]), max(new_size[1],size_of_room_grid[1])
	size_of_square_probability_matrix = [max_size[0] * 3, max_size[1] * 3]
	p_matrix = [[0] * size_of_square_probability_matrix[0] for i in range(size_of_square_probability_matrix[1])]
	c_p_matrix = [[0] * size_of_square_probability_matrix[0] for i in range(size_of_square_probability_matrix[1])]
	
	
	
load_probability_matrix_from_file("abraham_probability_matrix_file_test.txt")
