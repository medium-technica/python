PyQwt plots data with Numerical Python and PyQt


