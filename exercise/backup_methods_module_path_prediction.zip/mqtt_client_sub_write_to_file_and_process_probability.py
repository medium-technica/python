import paho.mqtt.client as mqtt
import time as t
import os.path
import os
import numpy as np
import math
import methods_module as mm

broker_address="localhost"
client = mqtt.Client("localhost_client")

def fn_on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
    client.subscribe("outTopic")
    client.subscribe("face_id")

def fn_on_message(client, userdata, msg):
	if(msg.topic == "face_id"):
		mm.set_user_id(msg.payload.decode())
	if(msg.topic == "outTopic"):
		mm.process_message(msg)
	if(msg.topic == "reset"):
		mm.initialize_variables([4,4])
		mm.initialize_file_names()

client.on_connect = fn_on_connect
client.on_message = fn_on_message

client.connect(broker_address, 1883, 60)
client.loop_forever()





