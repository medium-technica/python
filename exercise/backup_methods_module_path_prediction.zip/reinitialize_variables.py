import sys
import random as rand
import time as t
import paho.mqtt.client as mqtt #import the client1
#broker_address="192.168.1.184" 
#broker_address="iot.eclipse.org" #use external broker
broker_address="localhost"
client = mqtt.Client("client_id_01") #create new instance

client.publish("reset","")#publish
print ("Published!!!", msg_string)


