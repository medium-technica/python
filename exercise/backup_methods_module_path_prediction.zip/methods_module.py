import paho.mqtt.client as mqtt
import time as t
import os.path
import os
import numpy as np
import math
import random as rand
import scipy.misc

class msg():
	payload = 0
	topic = ""

def timestamp():
   now = t.time()
   localtime = t.localtime(now)
   milliseconds = '%03d' % int((now - int(now)) * 1000)
   return t.strftime('%Y%m%d%H%M%S', localtime) + milliseconds

def initialize_variables(size):
	global size_of_room_grid, size_of_square_probability_matrix
	global node_data_arrival_index_ascii_array, probability_matrix
	global row_length_probability_matrix, column_length_probability_matrix
	global node_row_index, node_column_index
	global current_node_position, previous_node_position, current_node_number, previous_node_number
	global node_data_count, iteration_count
	global user_id, column_length_room_grid, row_length_room_grid
	
	user_id = "null"
	
	size_of_room_grid = size[:]
	size_of_square_probability_matrix = [size_of_room_grid[0] * 3, size_of_room_grid[1] * 3]

	node_data_arrival_index_ascii_array = []
	probability_matrix = [[0] * size_of_square_probability_matrix[0] for i in range(size_of_square_probability_matrix[1])]

	row_length_probability_matrix = size_of_room_grid[0] * 3
	column_length_probability_matrix = size_of_room_grid[1] * 3

	row_length_room_grid = size_of_room_grid[0]
	column_length_room_grid = size_of_room_grid[1]
	
	node_row_index = 0
	node_column_index = 0
	previous_node_number = 0
	current_node_position = [0,0]
	previous_node_position = [0,0]
	
	node_data_count = 0
	iteration_count = 0

def initialize_file_names():
	global file_name_node_data, file_name_probability_matrix, user_id
	file_name_node_data = user_id+"_"+"node_data_file.txt"
	file_name_probability_matrix = user_id+"_"+"probability_matrix_file_test.txt"
	if (os.path.isfile(file_name_probability_matrix)):
		load_probability_matrix_from_file(file_name_probability_matrix)
	else:
		initialize_variables([4,4])

def node_number_value_to_prob_matrix_index(node_number_value):
	return 3*(node_number_value) + 1

def update_probability_matrix_from_new_node_data(node_number):
	position_coordinate = convert_node_index_to_position_coordinates(node_number)
	node_row_index = position_coordinate[0]
	node_column_index = position_coordinate[1]
	probability_matrix[node_number_value_to_prob_matrix_index(node_row_index)][node_number_value_to_prob_matrix_index(node_column_index)] += 1

def process_file_and_update_probability(file_name_node_data):
	file = open(file_name_node_data, "r") 
	for line_string in file: 
		temp_array = line_string.split(",")
		if (len(temp_array) >= 2):
			node_number_array.append(int(temp_array[1].strip())) 
		else:
			print ("File "+file_name_node_data+" format incorrect!!!")
	file.close()

	for node_number in node_number_array:
		update_probability_matrix_from_new_node_data(node_number)
		
def print_matrix_2d(matrix):
	for i in matrix[:]:
		for j in i[:]:
			print(j, end=' ')
		print ()

def load_probability_matrix_from_file(file_name):
	global row_length_probability_matrix
	file = open(file_name, "r")
	i=0
	for line_string in file:
		j=0
		temp_array = (line_string.strip()).split()
		if (len(temp_array) >= row_length_probability_matrix):
			for element in temp_array:
				probability_matrix[i][j]=int(element.strip())
				j+=1
			i+=1
		else:
			print ("Array length less than "+row_length_probability_matrix+"!!!")
			exit()
	file.close()

def save_probability_matrix_to_file(file_name):
	file = open(file_name,"w")
	write_string = ""
	for row in probability_matrix:
		for element in row:
			write_string += str(element) + " "
		write_string += "\n"
	file.write(write_string) 
	file.close()

def append_real_time_node_data_to_file(node_number):
	write_string = timestamp()+","+str(node_number)+"\n"
	now = t.time()
	localtime = t.localtime(now)
	file_name_string_node_data = t.strftime('%Y%m%d', localtime)+"_"+file_name_node_data
	file = open(file_name_string_node_data,"a+") 
	file.write(write_string)
	file.close()

def convert_node_index_to_position_coordinates(node_number):
	node_row_index = node_number//size_of_room_grid[0]
	node_column_index = node_number%size_of_room_grid[0]
	position_coordinate = [node_row_index, node_column_index]
	return position_coordinate

def cart2pol(x, y):
    rho = np.sqrt(x**2 + y**2)
    phi = math.degrees(np.arctan2(y, x))
    return([rho, phi])

def calculate_displacement_vector_angle(previous_position, current_position):
	displacement_gradient = [0]*len(current_position[:])
	for i in range(len(displacement_gradient)):
		displacement_gradient[i] = previous_position[i] - current_position[i]
	[rho, phi] = cart2pol(displacement_gradient[0], displacement_gradient[1])
	
	return ([rho,phi])

def approximate_angle_resolution_to_45_degrees(angle):
	approximated_angle = str(round(angle / 45) * 45)
	return approximated_angle


def convert_angle_to_direction_coordinate(angle):
	angle = str(angle)
	switch = {
	'0': [-1,0],
	'45': [-1,-1],
	'90': [0,-1],
	'135': [1,-1],
	'180': [1,0],
	'-45': [-1,1],
	'-90':[0,1],
	'-135':[1,1],
	'-180':[1,0]
	}	
	return switch[angle]
	
def convert_node_grid_coordinate_to_probability_matrix_coordinate(node_position):
	row_index = node_number_value_to_prob_matrix_index(node_position[0])
	column_index = node_number_value_to_prob_matrix_index(node_position[1])
	return [row_index, column_index]

def calculate_and_insert_probability_data_into_probability_matrix(previous_position, angle_of_current_node_number):
	approximated_angle = approximate_angle_resolution_to_45_degrees(angle_of_current_node_number)
	direction_coordinate = convert_angle_to_direction_coordinate(approximated_angle)
	previous_position_probability_matrix = convert_node_grid_coordinate_to_probability_matrix_coordinate(previous_position)
	probability_update_position = np.add(previous_position_probability_matrix, direction_coordinate)
	probability_matrix[probability_update_position[0]][probability_update_position[1]] += 1

def process_message(msg):
	global node_data_count, previous_node_position, current_node_position, current_node_number, previous_node_number
	global angle_of_current_node_number
	approximated_angle = 0
	os.system('cls')
	current_node_number = int(msg.payload)
	current_node_position = convert_node_index_to_position_coordinates(current_node_number)
	append_real_time_node_data_to_file(current_node_number)
	update_probability_matrix_from_new_node_data(current_node_number)
	if (node_data_count > 0):
		if(current_node_number > 0):
			position_vector_polar_coordinate = calculate_displacement_vector_angle(previous_node_position, current_node_position)
			angle_of_current_node_number = position_vector_polar_coordinate[1]
			distance_from_previous_position = position_vector_polar_coordinate[0]
			if (distance_from_previous_position>0):
				approximated_angle = approximate_angle_resolution_to_45_degrees(angle_of_current_node_number)
				calculate_and_insert_probability_data_into_probability_matrix(previous_node_position, angle_of_current_node_number)
		else:
			pass
	#save_probability_matrix_to_file(file_name_probability_matrix)
	#file_name_backup_probability_matrix = t.strftime("%Y%m%d")+"_"+file_name_probability_matrix
	#save_probability_matrix_to_file(file_name_backup_probability_matrix)
	#scipy.misc.imsave(file_name_probability_matrix[:-4]+'.jpg', probability_matrix)
	print_matrix_2d(probability_matrix)

	next_node_number = find_most_probable_next_node_avoiding_previous_node(current_node_number, previous_node_number)
	#destination_node_number = obtain_destination_node_number(current_node_number)
	[max_stayed_node_number, largest_stay_count] = find_max_stayed_node_in_the_forward_path(current_node_number, previous_node_number, current_node_number, 0)
	print ("Current Node:", current_node_number, ", Next Probable Node:", next_node_number, ", Destination Node:",max_stayed_node_number)

	previous_node_position = current_node_position[:]
	previous_node_number = current_node_number
	node_data_count += 1		

def scan_probability_matrix_and_get_next_nodes_around_node_number_with_probability_values(node_number):
	node_coordinates = convert_node_index_to_position_coordinates(node_number)
	probability_matrix_coordinate = convert_node_grid_coordinate_to_probability_matrix_coordinate(node_coordinates)
	next_nodes_probability_values_array = []
	next_nodes_array = []
	for i in [-1,0,1]:
		for j in [-1,0,1]:
			if ((i!=0)|(j!=0)):
				probability_value = probability_matrix[probability_matrix_coordinate[0]+i][probability_matrix_coordinate[1]+j]
				next_nodes_probability_values_array.append(probability_value)
				next_node_number = convert_node_coordinate_to_node_number(np.add(node_coordinates,[i,j]))
				next_nodes_array.append(next_node_number)
	return_array = [next_nodes_array, next_nodes_probability_values_array]
	return return_array 


def convert_probability_matrix_index_to_node_grid_index(probability_matrix_index):
	return (probability_matrix_index - 1)/3
	
	
def find_most_probable_next_node_avoiding_previous_node(current_node_number, previous_node_number):
	[next_nodes_array, next_nodes_probability_values_array] = scan_probability_matrix_and_get_next_nodes_around_node_number_with_probability_values(current_node_number)
	largest_probability_value = 0
	next_node_number = current_node_number
	for [probability_value, node_number] in zip(next_nodes_probability_values_array, next_nodes_array):
		if (node_number!=previous_node_number):
			if (probability_value > largest_probability_value):
				largest_probability_value = probability_value
				next_node_number = node_number
	return [next_node_number, largest_probability_value]
	
def scan_probability_matrix_and_obtain_most_probable_next_node(node_number):
	node_coordinates = convert_node_index_to_position_coordinates(node_number)
	probability_matrix_coordinate = convert_node_grid_coordinate_to_probability_matrix_coordinate(node_coordinates)
	largest_probability_value = 0
	coordinates_of_largest_probability = [0,0]
	next_node_coordinates = [0,0]
	for i in [-1,0,1]:
		for j in [-1,0,1]:
			if ((i+j)!=0):
				probability_value = probability_matrix[probability_matrix_coordinate[0]+i][probability_matrix_coordinate[1]+j]
				if(probability_value > largest_probability_value):
					largest_probability_value = probability_value
					next_node_coordinates = np.add(node_coordinates,[i,j])
	if (largest_probability_value == 0):
		next_node_number = node_number
	else:
		next_node_number = convert_node_coordinate_to_node_number(next_node_coordinates)
	return next_node_number

def obtain_destination_node_number(node_number):
	global iteration_count
	iteration_count+=1
	next_node_number = scan_probability_matrix_and_obtain_most_probable_next_node(node_number)
	if (next_node_number!=node_number):
		if (iteration_count<(size_of_room_grid[0]*size_of_room_grid[1])):
			return obtain_destination_node_number(next_node_number)
	iteration_count = 0
	return node_number

def check_if_node_number_is_present_in_covered_nodes(node_number, node_number_array):
	for i in node_number_array:
		if (i == node_number):
			return 1
		else:
			return 0

def find_max_stayed_node_in_the_forward_path(current_node_number, previous_node_number, max_stayed_node_number, largest_stay_count):
	global iteration_count
	[next_node_number, probability_value] = find_most_probable_next_node_avoiding_previous_node(current_node_number, previous_node_number)
	current_node_coordinates = convert_node_index_to_position_coordinates(current_node_number)
	probability_matrix_coordinates = convert_node_grid_coordinate_to_probability_matrix_coordinate(current_node_coordinates)
	#t.sleep(1)
	iteration_count+=1
	stay_count = probability_matrix[probability_matrix_coordinates[0]][probability_matrix_coordinates[1]]
	if(stay_count > largest_stay_count):
		largest_stay_count = stay_count
		max_stayed_node_number = current_node_number
	if (current_node_number!=next_node_number):
		if (iteration_count<(size_of_room_grid[0]*size_of_room_grid[1])):
			[max_stayed_node_number, largest_stay_count] = find_max_stayed_node_in_the_forward_path(next_node_number, current_node_number, max_stayed_node_number, largest_stay_count)
			iteration_count = 0
	#print("P. Node: ",previous_node_number, "C. Node:", current_node_number, "N. Node:", next_node_number, "Stay Count:", largest_stay_count)
	return [max_stayed_node_number, largest_stay_count]

def convert_node_coordinate_to_node_number(node_coordinates):
	node_number = node_coordinates[0]*column_length_room_grid + node_coordinates[1]
	return node_number 

def set_user_id(username):
	global user_id
	user_id = username
	initialize_file_names()
	

def test_run():
	global node_data_count, previous_node_position
	test_node_number_sequence = {
	'0': [0, 1,1,1,1,1,1,1,1, 2, 7, 7, 7, 7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,2, 1, 0, 0],
	'1': [0, 5, 6,6,6,6,6,6,10,11,11,11,11,11,10, 6, 5, 0],
	'2': [0, 4, 8,13,14,15,15,15,15,15,15,15,15,14,14,14,14,14,13, 8, 4, 0],
	
	}
	for j in range(6):
		sequence = test_node_number_sequence[str(int(round(2*rand.random())))]
		for i in sequence:
			msg.payload = str(i) #str(int(round(15*rand.random())))
			process_message(msg)
			#t.sleep(1)
		node_data_count = 0
		previous_node_position = 0
	while(msg.payload<15):
		msg.payload = input("Enter node number:")
		process_message(msg)
			
	#current_node_number = 0
	#previous_node_number = 0
	#iteration_count = 0;
	#[max_stayed_node_number, largest_stay_count] = find_max_stayed_node_in_the_forward_path(current_node_number, previous_node_number, current_node_number, 0)
	#print (previous_node_number, current_node_number, max_stayed_node_number, largest_stay_count)

initialize_variables([4,4])
initialize_file_names()
test_run()

